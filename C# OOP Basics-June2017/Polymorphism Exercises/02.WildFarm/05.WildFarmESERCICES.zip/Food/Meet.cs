﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Meet : Food
{
    public Meet(int quantity) : base(quantity)
    {
    }

    public override string ToString()
    {
        return base.ToString();
    }
}
